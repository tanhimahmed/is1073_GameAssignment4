﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {
	public float speed;
	public Rigidbody player1;
	public int lives;
	public Text scoreDisplay;
	public Vector3 startPos = new Vector3(0.0f,0.5f,0.0f);

	// Use this for initialization
	void Start () {
		player1 = GetComponent<Rigidbody> ();
		lives = 5;
		scoreDisplay.text = "Lives: " + lives;
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		// movement handled for desktop play
		if (SystemInfo.deviceType == DeviceType.Desktop) {
			float moveHorizontal = Input.GetAxis ("Horizontal");
			float moveVertical = Input.GetAxis ("Vertical");

			Vector3 move = new Vector3 (moveHorizontal, 0.0f, moveVertical);

			player1.AddForce (move * speed);
		} else if (SystemInfo.deviceType == DeviceType.Handheld) {
			// else handle movement using accelerometer controls on mobile platforms
			Vector3 movement = new Vector3 (Input.acceleration.x, 0.0f, Input.acceleration.y);
			player1.AddForce (movement * speed * Time.deltaTime);
		} else {
			// unsupported device, print to Unity console
			print ("You are playing on an unsupported device! Please use a desktop or mobile platform.");
		}
	}

	void OnTriggerEnter(Collider other){
		
		if (other.gameObject.CompareTag ("Trap")) {
			this.gameObject.GetComponent<Rigidbody> ();
			lives--;
			scoreDisplay.text = "Lives: " + lives;
			player1.MovePosition (startPos);
		} else if (other.gameObject.CompareTag ("Goal")) {
			scoreDisplay.text = "You Won!";
			lives = 5;
			player1.MovePosition (startPos);
		}
	}

}
